public class LandLineSubscriber extends Subscriber {

    private int noOfSTDCallMinutes;
    private double costPerEachSTDMinute;

    public LandLineSubscriber(String subscriberName, long subscriberId,
                              long subscriberPhoneNumber, String subscriberPlanName,
                              int subscriberFreeCalls, double subscriberPackageCost,
                              int subscriberExtraCallsInMinutes,
                              double subscriberExtraCallCostPerMinutes,
                              double subscriberTaxOnBill,
                              int noOfSTDCallMinutes,
                              double costPerEachSTDMinute) {

        super(subscriberName, subscriberId, subscriberPhoneNumber,
              subscriberPlanName, subscriberFreeCalls, subscriberPackageCost,
              subscriberExtraCallsInMinutes,
              subscriberExtraCallCostPerMinutes,
              subscriberTaxOnBill);

        this.noOfSTDCallMinutes = noOfSTDCallMinutes;
        this.costPerEachSTDMinute = costPerEachSTDMinute;
    }

    @Override
    public void getSubscriberDetails() {
        super.getSubscriberDetails();
        System.out.println("STD Call Minutes         : " + noOfSTDCallMinutes);
        System.out.println("STD Cost/Minute          : Rs." + costPerEachSTDMinute);
    }

    public double calculateBill() {
        double extraCallCost =
                subscriberExtraCallsInMinutes * subscriberExtraCallCostPerMinutes;

        double stdCallCost =
                noOfSTDCallMinutes * costPerEachSTDMinute;

        double subtotal =
                subscriberPackageCost + extraCallCost + stdCallCost;

        double taxAmount =
                subtotal * subscriberTaxOnBill / 100;

        double totalBill = subtotal + taxAmount;

        System.out.println("\n========== LANDLINE BILL ==========");
        System.out.println("Package Cost             : Rs." + subscriberPackageCost);
        System.out.println("Extra Local Call Cost    : Rs." + extraCallCost);
        System.out.println("STD Call Cost            : Rs." + stdCallCost);
        System.out.println("Subtotal                 : Rs." + subtotal);
        System.out.println("Tax (" + subscriberTaxOnBill + "%)              : Rs." + taxAmount);
        System.out.println("-----------------------------------");
        System.out.println("TOTAL BILL               : Rs." + totalBill);
        System.out.println("===================================");

        return totalBill;
    }
}
