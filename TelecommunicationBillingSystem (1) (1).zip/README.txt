TELECOMMUNICATION BILLING SYSTEM

Files:
1. Subscriber.java - Superclass
2. MobileSubscriber.java - Subclass
3. LandLineSubscriber.java - Subclass
4. Main.java - Main execution class

How to run:
1. Open the folder in Eclipse, IntelliJ IDEA, VS Code, or Command Prompt.
2. Compile:
   javac *.java
3. Run:
   java Main

The application supports Mobile and LandLine subscribers and calculates:
Package Cost + Extra Call Cost + Roaming/STD Cost + Tax.
