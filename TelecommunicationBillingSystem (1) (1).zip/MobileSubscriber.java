public class MobileSubscriber extends Subscriber {

    private int roamingNoOfMinutes;
    private double roamingCostPerMinute;

    public MobileSubscriber(String subscriberName, long subscriberId,
                            long subscriberPhoneNumber, String subscriberPlanName,
                            int subscriberFreeCalls, double subscriberPackageCost,
                            int subscriberExtraCallsInMinutes,
                            double subscriberExtraCallCostPerMinutes,
                            double subscriberTaxOnBill,
                            int roamingNoOfMinutes,
                            double roamingCostPerMinute) {

        super(subscriberName, subscriberId, subscriberPhoneNumber,
              subscriberPlanName, subscriberFreeCalls, subscriberPackageCost,
              subscriberExtraCallsInMinutes,
              subscriberExtraCallCostPerMinutes,
              subscriberTaxOnBill);

        this.roamingNoOfMinutes = roamingNoOfMinutes;
        this.roamingCostPerMinute = roamingCostPerMinute;
    }

    @Override
    public void getSubscriberDetails() {
        super.getSubscriberDetails();
        System.out.println("Roaming Minutes          : " + roamingNoOfMinutes);
        System.out.println("Roaming Cost/Minute      : Rs." + roamingCostPerMinute);
    }

    public double calculateBill() {
        double extraCallCost =
                subscriberExtraCallsInMinutes * subscriberExtraCallCostPerMinutes;

        double roamingCost =
                roamingNoOfMinutes * roamingCostPerMinute;

        double subtotal =
                subscriberPackageCost + extraCallCost + roamingCost;

        double taxAmount =
                subtotal * subscriberTaxOnBill / 100;

        double totalBill = subtotal + taxAmount;

        System.out.println("\n========== MOBILE BILL ==========");
        System.out.println("Package Cost             : Rs." + subscriberPackageCost);
        System.out.println("Extra Call Cost          : Rs." + extraCallCost);
        System.out.println("Roaming Call Cost        : Rs." + roamingCost);
        System.out.println("Subtotal                 : Rs." + subtotal);
        System.out.println("Tax (" + subscriberTaxOnBill + "%)              : Rs." + taxAmount);
        System.out.println("----------------------------------");
        System.out.println("TOTAL BILL               : Rs." + totalBill);
        System.out.println("==================================");

        return totalBill;
    }
}
