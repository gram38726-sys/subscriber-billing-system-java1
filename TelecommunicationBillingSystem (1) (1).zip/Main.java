import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("==========================================");
        System.out.println("     TELECOMMUNICATION BILLING SYSTEM");
        System.out.println("==========================================");

        System.out.println("\nSelect Subscriber Type:");
        System.out.println("1. Mobile Subscriber");
        System.out.println("2. LandLine Subscriber");
        System.out.print("Enter your choice: ");

        int choice = sc.nextInt();
        sc.nextLine();

        Subscriber subscriber;

        if (choice == 1) {

            System.out.println("\n----- MOBILE SUBSCRIBER REGISTRATION -----");

            System.out.print("Enter Subscriber Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Subscriber ID: ");
            long id = sc.nextLong();

            System.out.print("Enter Phone Number: ");
            long phone = sc.nextLong();
            sc.nextLine();

            System.out.print("Enter Plan Name: ");
            String plan = sc.nextLine();

            System.out.print("Enter Free Call Minutes: ");
            int freeCalls = sc.nextInt();

            System.out.print("Enter Monthly Package Cost: ");
            double packageCost = sc.nextDouble();

            System.out.print("Enter Extra Call Minutes Used: ");
            int extraMinutes = sc.nextInt();

            System.out.print("Enter Extra Call Cost Per Minute: ");
            double extraCost = sc.nextDouble();

            System.out.print("Enter Tax Percentage: ");
            double tax = sc.nextDouble();

            System.out.print("Enter Roaming Minutes: ");
            int roamingMinutes = sc.nextInt();

            System.out.print("Enter Roaming Cost Per Minute: ");
            double roamingCost = sc.nextDouble();

            subscriber = new MobileSubscriber(
                    name, id, phone, plan, freeCalls, packageCost,
                    extraMinutes, extraCost, tax,
                    roamingMinutes, roamingCost
            );

            subscriber.getSubscriberDetails();

            MobileSubscriber mobile = (MobileSubscriber) subscriber;
            mobile.calculateBill();

        } else if (choice == 2) {

            System.out.println("\n----- LANDLINE SUBSCRIBER REGISTRATION -----");

            System.out.print("Enter Subscriber Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Subscriber ID: ");
            long id = sc.nextLong();

            System.out.print("Enter Phone Number: ");
            long phone = sc.nextLong();
            sc.nextLine();

            System.out.print("Enter Plan Name: ");
            String plan = sc.nextLine();

            System.out.print("Enter Free Call Minutes: ");
            int freeCalls = sc.nextInt();

            System.out.print("Enter Monthly Package Cost: ");
            double packageCost = sc.nextDouble();

            System.out.print("Enter Extra Call Minutes Used: ");
            int extraMinutes = sc.nextInt();

            System.out.print("Enter Extra Call Cost Per Minute: ");
            double extraCost = sc.nextDouble();

            System.out.print("Enter Tax Percentage: ");
            double tax = sc.nextDouble();

            System.out.print("Enter STD Call Minutes: ");
            int stdMinutes = sc.nextInt();

            System.out.print("Enter STD Cost Per Minute: ");
            double stdCost = sc.nextDouble();

            subscriber = new LandLineSubscriber(
                    name, id, phone, plan, freeCalls, packageCost,
                    extraMinutes, extraCost, tax,
                    stdMinutes, stdCost
            );

            subscriber.getSubscriberDetails();

            LandLineSubscriber landline = (LandLineSubscriber) subscriber;
            landline.calculateBill();

        } else {
            System.out.println("\nInvalid choice!");
            System.out.println("Please select either 1 or 2.");
        }

        System.out.println("\nThank you for using the Billing System!");

        sc.close();
    }
}
