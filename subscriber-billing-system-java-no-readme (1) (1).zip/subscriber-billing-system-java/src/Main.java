public class Main {
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("       SUBSCRIBER BILLING SYSTEM");
        System.out.println("========================================");
        MobileSubscriber mobile = new MobileSubscriber("Rahul",101,9876543210L,"Gold Postpaid",500,599,50,1.5,20,2.0);
        mobile.getSubscriberDetails(); mobile.calculateBill();
        LandLineSubscriber landline = new LandLineSubscriber("Arun",102,9988776655L,"Home Plan",300,399,40,1.0,30,2.5);
        landline.getSubscriberDetails(); landline.calculateBill();
    }
}
