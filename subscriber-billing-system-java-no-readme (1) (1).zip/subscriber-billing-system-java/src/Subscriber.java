public class Subscriber {
    String subscriberName; long subscriberId; long subscriberPhoneNumber; String subscriberPlanName;
    int subscriberFreeCalls; double subscriberPackageCost; int subscriberExtraCallsInMinutes;
    double subscriberExtraCallCostPerMinutes; double subscriberTaxOnBill = 10;
    Subscriber(String name,long id,long phone,String plan,int freeCalls,double packageCost,int extraMinutes,double extraCost){
        subscriberName=name; subscriberId=id; subscriberPhoneNumber=phone; subscriberPlanName=plan;
        subscriberFreeCalls=freeCalls; subscriberPackageCost=packageCost; subscriberExtraCallsInMinutes=extraMinutes; subscriberExtraCallCostPerMinutes=extraCost;
    }
    void getSubscriberDetails(){
        System.out.println("\n----- Subscriber Details -----");
        System.out.println("Name             : "+subscriberName); System.out.println("ID               : "+subscriberId);
        System.out.println("Phone Number     : "+subscriberPhoneNumber); System.out.println("Plan Name        : "+subscriberPlanName);
        System.out.println("Free Calls       : "+subscriberFreeCalls); System.out.println("Package Cost     : Rs."+subscriberPackageCost);
        System.out.println("Extra Call Min.  : "+subscriberExtraCallsInMinutes); System.out.println("Extra Call Cost  : Rs."+subscriberExtraCallCostPerMinutes);
        System.out.println("Tax              : 10%");
    }
}
