public class LandLineSubscriber extends Subscriber {
    int noOfSTDCallMinutes; double costPerEachSTDMinute;
    LandLineSubscriber(String name,long id,long phone,String plan,int freeCalls,double packageCost,int extraMinutes,double extraCost,int stdMinutes,double stdCost){
        super(name,id,phone,plan,freeCalls,packageCost,extraMinutes,extraCost); noOfSTDCallMinutes=stdMinutes; costPerEachSTDMinute=stdCost;
    }
    @Override void getSubscriberDetails(){ super.getSubscriberDetails(); System.out.println("Subscriber Type  : Landline"); System.out.println("STD Call Minutes : "+noOfSTDCallMinutes); System.out.println("STD Cost/Min     : Rs."+costPerEachSTDMinute); }
    void calculateBill(){
        double extraCallCharge=subscriberExtraCallsInMinutes*subscriberExtraCallCostPerMinutes; double stdCharge=noOfSTDCallMinutes*costPerEachSTDMinute;
        double subtotal=subscriberPackageCost+extraCallCharge+stdCharge; double tax=subtotal*subscriberTaxOnBill/100; double total=subtotal+tax;
        System.out.println("\n========= LANDLINE BILL ========="); System.out.println("Package Cost      : Rs."+subscriberPackageCost);
        System.out.println("Extra Call Charge : Rs."+extraCallCharge); System.out.println("STD Call Charge   : Rs."+stdCharge);
        System.out.println("Subtotal          : Rs."+subtotal); System.out.println("Tax (10%)         : Rs."+tax); System.out.println("---------------------------------");
        System.out.println("TOTAL BILL        : Rs."+total); System.out.println("=================================");
    }
}
