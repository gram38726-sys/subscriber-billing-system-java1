public class MobileSubscriber extends Subscriber {
    int roamingNoOfMinutes; double roamingCostPerMinute;
    MobileSubscriber(String name,long id,long phone,String plan,int freeCalls,double packageCost,int extraMinutes,double extraCost,int roamingMinutes,double roamingCost){
        super(name,id,phone,plan,freeCalls,packageCost,extraMinutes,extraCost); roamingNoOfMinutes=roamingMinutes; roamingCostPerMinute=roamingCost;
    }
    @Override void getSubscriberDetails(){ super.getSubscriberDetails(); System.out.println("Subscriber Type  : Mobile Postpaid"); System.out.println("Roaming Minutes  : "+roamingNoOfMinutes); System.out.println("Roaming Cost/Min : Rs."+roamingCostPerMinute); }
    void calculateBill(){
        double extraCallCharge=subscriberExtraCallsInMinutes*subscriberExtraCallCostPerMinutes;
        double roamingCharge=roamingNoOfMinutes*roamingCostPerMinute;
        double subtotal=subscriberPackageCost+extraCallCharge+roamingCharge; double tax=subtotal*subscriberTaxOnBill/100; double total=subtotal+tax;
        System.out.println("\n========== MOBILE BILL =========="); System.out.println("Package Cost      : Rs."+subscriberPackageCost);
        System.out.println("Extra Call Charge : Rs."+extraCallCharge); System.out.println("Roaming Charge    : Rs."+roamingCharge);
        System.out.println("Subtotal          : Rs."+subtotal); System.out.println("Tax (10%)         : Rs."+tax); System.out.println("---------------------------------");
        System.out.println("TOTAL BILL        : Rs."+total); System.out.println("=================================");
    }
}
